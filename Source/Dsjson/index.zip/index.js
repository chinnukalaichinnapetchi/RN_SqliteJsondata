
import { DSdata } from "./jsondata"



export const set1 = [
    {
        "permit_id": 2,
        "permit_reference_number": "AD00109973359-01",
        "modified_date": "2023-10-16T06:50:15"
    },
    {
        "permit_id": 7,
        "permit_reference_number": "AD00140844235-01",
        "modified_date": "2023-10-18T10:28:48"
    },
    {
        "permit_id": 9,
        "permit_reference_number": "AD00159868900-01",
        "modified_date": "2023-07-31T16:30:00"
    },
    {
        "permit_id": 12,
        "permit_reference_number": "AD00194263597-01",
        "modified_date": "2023-10-17T05:51:21"
    },
    {
        "permit_id": 13,
        "permit_reference_number": "AD001CF1-01",
        "modified_date": "2023-07-17T16:30:00"
    },
    {
        "permit_id": 14,
        "permit_reference_number": "AD001CF2-01",
        "modified_date": "2023-07-17T16:30:00"
    },
    {
        "permit_id": 15,
        "permit_reference_number": "AD001CF3-01",
        "modified_date": "2023-07-17T16:30:00"
    },
    {
        "permit_id": 16,
        "permit_reference_number": "AD001CF4-01",
        "modified_date": "2023-07-17T16:30:00"
    },
    {
        "permit_id": 17,
        "permit_reference_number": "AD001CF5-01",
        "modified_date": "2023-07-17T16:30:00"
    },
    {
        "permit_id": 25,
        "permit_reference_number": "AD001NOEX-2-EXCA-01",
        "modified_date": "2021-04-30T16:30:00"
    },
    {
        "permit_id": 27,
        "permit_reference_number": "AD001STREETMANAGER-TEST-01",
        "modified_date": "2023-03-08T16:30:00"
    },
    {
        "permit_id": 31,
        "permit_reference_number": "AD001SYMTEST56-02",
        "modified_date": "2023-03-06T16:30:00"
    },
    {
        "permit_id": 37,
        "permit_reference_number": "AD002ANCILLARY-02",
        "modified_date": "2023-04-11T16:30:00"
    },
    {
        "permit_id": 41,
        "permit_reference_number": "AD002TESTAC-01",
        "modified_date": "2023-03-17T16:30:00"
    },
    {
        "permit_id": 44,
        "permit_reference_number": "AD002TESTINGPROJECTREF-01",
        "modified_date": "2021-03-03T16:30:00"
    },
    {
        "permit_id": 46,
        "permit_reference_number": "AD002ZDSBMXCBVJDZFJ-01",
        "modified_date": "2021-01-27T16:30:00"
    },
    {
        "permit_id": 51,
        "permit_reference_number": "AD01464568713-01",
        "modified_date": "2023-07-04T12:37:00"
    },
    {
        "permit_id": 52,
        "permit_reference_number": "AD021DESI3333-01",
        "modified_date": "2021-06-09T15:20:00"
    },
    {
        "permit_id": 53,
        "permit_reference_number": "AD021DESI4444-01",
        "modified_date": "2021-06-09T15:53:00"
    },
    {
        "permit_id": 54,
        "permit_reference_number": "AD021DESI5555-01",
        "modified_date": "2021-06-10T09:50:00"
    },
    {
        "permit_id": 58,
        "permit_reference_number": "AD022TESTING1-01",
        "modified_date": "2023-06-12T16:30:00"
    },
    {
        "permit_id": 62,
        "permit_reference_number": "AD02410810587-02",
        "modified_date": "2023-06-21T14:28:00"
    },
    {
        "permit_id": 66,
        "permit_reference_number": "AD02410810610-01",
        "modified_date": "2023-06-23T16:30:00"
    },
    {
        "permit_id": 69,
        "permit_reference_number": "AD02410810632-01",
        "modified_date": "2023-06-29T14:32:00"
    },
    {
        "permit_id": 70,
        "permit_reference_number": "AD02910663949-01",
        "modified_date": "2023-08-10T16:30:00"
    },
    {
        "permit_id": 71,
        "permit_reference_number": "AD02910680478-01",
        "modified_date": "2023-08-23T10:32:00"
    },
    {
        "permit_id": 72,
        "permit_reference_number": "AD02910810435-01",
        "modified_date": "2023-05-30T10:31:00"
    },
    {
        "permit_id": 73,
        "permit_reference_number": "AD02910810435_1-01",
        "modified_date": "2023-06-05T16:30:00"
    },
    {
        "permit_id": 74,
        "permit_reference_number": "AD02910810435_2-01",
        "modified_date": "2023-10-16T09:30:13"
    },
    {
        "permit_id": 75,
        "permit_reference_number": "AD02910810435_3-01",
        "modified_date": "2023-06-07T16:30:00"
    },
    {
        "permit_id": 76,
        "permit_reference_number": "AD02910810435_AC-01",
        "modified_date": "2023-06-05T16:30:00"
    },
    {
        "permit_id": 77,
        "permit_reference_number": "AD02910810436-01",
        "modified_date": "2023-10-01T06:09:42"
    },
    {
        "permit_id": 78,
        "permit_reference_number": "AD02910810437-01",
        "modified_date": "2023-10-01T07:09:42"
    },
    {
        "permit_id": 84,
        "permit_reference_number": "AD02910810470-01",
        "modified_date": "2023-05-26T16:30:00"
    },
    {
        "permit_id": 85,
        "permit_reference_number": "AD02910810470_3-01",
        "modified_date": "2023-10-02T09:59:42"
    },
    {
        "permit_id": 86,
        "permit_reference_number": "AD02910810471-01",
        "modified_date": "2023-10-01T12:29:42"
    },
    {
        "permit_id": 87,
        "permit_reference_number": "AD02910810504-01",
        "modified_date": "2023-08-15T16:30:00"
    },
    {
        "permit_id": 88,
        "permit_reference_number": "AD02910810564-01",
        "modified_date": "2023-06-22T16:30:00"
    },
    {
        "permit_id": 90,
        "permit_reference_number": "AD02910810567-02",
        "modified_date": "2023-06-29T12:15:00"
    },
    {
        "permit_id": 94,
        "permit_reference_number": "AD02910810572-01",
        "modified_date": "2023-06-21T12:30:00"
    },
    {
        "permit_id": 95,
        "permit_reference_number": "AD02910810584_1-01",
        "modified_date": "2023-06-22T16:30:00"
    },
    {
        "permit_id": 97,
        "permit_reference_number": "AD02910810624-02",
        "modified_date": "2023-06-22T14:39:00"
    },
    {
        "permit_id": 100,
        "permit_reference_number": "AD02910810664-03",
        "modified_date": "2023-07-05T15:07:00"
    },
    {
        "permit_id": 101,
        "permit_reference_number": "AD02910810666-01",
        "modified_date": "2023-08-10T16:30:00"
    },
    {
        "permit_id": 102,
        "permit_reference_number": "AD02910810669_1-01",
        "modified_date": "2023-08-09T10:43:00"
    },
    {
        "permit_id": 103,
        "permit_reference_number": "AD02910810684-01",
        "modified_date": "2023-08-08T13:50:00"
    },
    {
        "permit_id": 107,
        "permit_reference_number": "AD02910810768-03",
        "modified_date": "2023-07-07T14:54:00"
    },
    {
        "permit_id": 108,
        "permit_reference_number": "AD02910811032-01",
        "modified_date": "2023-08-15T16:30:00"
    },
    {
        "permit_id": 109,
        "permit_reference_number": "AD02910811034-01",
        "modified_date": "2023-08-15T16:30:00"
    },
    {
        "permit_id": 111,
        "permit_reference_number": "AD02910811066_1-01",
        "modified_date": "2023-08-23T14:38:00"
    },
    {
        "permit_id": 114,
        "permit_reference_number": "AD0292345234-01",
        "modified_date": "2023-06-23T16:30:00"
    },
]


export const set2 = [
    {
        "permit_id": 2,
        "permit_reference_number": "AD00109973359-01",
        "modified_date": "2023-10-16T06:50:15"
    },
    {
        "permit_id": 7,
        "permit_reference_number": "AD00140844235-01",
        "modified_date": "2023-10-18T10:28:48"
    },
    {
        "permit_id": 9,
        "permit_reference_number": "AD00159868900-01",
        "modified_date": "2023-07-31T16:30:00"
    },
    {
        "permit_id": 12,
        "permit_reference_number": "AD00194263597-01",
        "modified_date": "2023-10-17T05:51:21"
    },
    {
        "permit_id": 13,
        "permit_reference_number": "AD001CF1-01",
        "modified_date": "2023-07-17T16:30:00"
    },
    {
        "permit_id": 14,
        "permit_reference_number": "AD001CF2-01",
        "modified_date": "2023-07-17T16:30:00"
    },
    {
        "permit_id": 15,
        "permit_reference_number": "AD001CF3-01",
        "modified_date": "2023-07-17T16:30:00"
    },
    {
        "permit_id": 16,
        "permit_reference_number": "AD001CF4-01",
        "modified_date": "2023-07-17T16:30:00"
    },
    {
        "permit_id": 17,
        "permit_reference_number": "AD001CF5-01",
        "modified_date": "2023-07-17T16:30:00"
    },
    {
        "permit_id": 25,
        "permit_reference_number": "AD001NOEX-2-EXCA-01",
        "modified_date": "2021-04-30T16:30:00"
    },
    {
        "permit_id": 27,
        "permit_reference_number": "AD001STREETMANAGER-TEST-01",
        "modified_date": "2023-03-08T16:30:00"
    },
    {
        "permit_id": 31,
        "permit_reference_number": "AD001SYMTEST56-02",
        "modified_date": "2023-03-06T16:30:00"
    },
    {
        "permit_id": 37,
        "permit_reference_number": "AD002ANCILLARY-02",
        "modified_date": "2023-04-11T16:30:00"
    },
    {
        "permit_id": 41,
        "permit_reference_number": "AD002TESTAC-01",
        "modified_date": "2023-03-17T16:30:00"
    },
    {
        "permit_id": 44,
        "permit_reference_number": "AD002TESTINGPROJECTREF-01",
        "modified_date": "2021-03-03T16:30:00"
    },
    {
        "permit_id": 46,
        "permit_reference_number": "AD002ZDSBMXCBVJDZFJ-01",
        "modified_date": "2021-01-27T16:30:00"
    },
    {
        "permit_id": 51,
        "permit_reference_number": "AD01464568713-01",
        "modified_date": "2023-07-04T12:37:00"
    },
    {
        "permit_id": 52,
        "permit_reference_number": "AD021DESI3333-01",
        "modified_date": "2021-06-09T15:20:00"
    },
    {
        "permit_id": 53,
        "permit_reference_number": "AD021DESI4444-01",
        "modified_date": "2021-06-09T15:53:00"
    },
    {
        "permit_id": 54,
        "permit_reference_number": "AD021DESI5555-01",
        "modified_date": "2021-06-10T09:50:00"
    },
    {
        "permit_id": 58,
        "permit_reference_number": "AD022TESTING1-01",
        "modified_date": "2023-06-12T16:30:00"
    },
    {
        "permit_id": 62,
        "permit_reference_number": "AD02410810587-02",
        "modified_date": "2023-06-21T14:28:00"
    },
    {
        "permit_id": 66,
        "permit_reference_number": "AD02410810610-01",
        "modified_date": "2023-06-23T16:30:00"
    },
    {
        "permit_id": 69,
        "permit_reference_number": "AD02410810632-01",
        "modified_date": "2023-06-29T14:32:00"
    },
    {
        "permit_id": 70,
        "permit_reference_number": "AD02910663949-01",
        "modified_date": "2023-08-10T16:30:00"
    },
    {
        "permit_id": 71,
        "permit_reference_number": "AD02910680478-01",
        "modified_date": "2023-08-23T10:32:00"
    },
    {
        "permit_id": 72,
        "permit_reference_number": "AD02910810435-01",
        "modified_date": "2023-05-30T10:31:00"
    },
    {
        "permit_id": 73,
        "permit_reference_number": "AD02910810435_1-01",
        "modified_date": "2023-06-05T16:30:00"
    },
    {
        "permit_id": 74,
        "permit_reference_number": "AD02910810435_2-01",
        "modified_date": "2023-10-16T09:30:13"
    },
    {
        "permit_id": 75,
        "permit_reference_number": "AD02910810435_3-01",
        "modified_date": "2023-06-07T16:30:00"
    },
    {
        "permit_id": 76,
        "permit_reference_number": "AD02910810435_AC-01",
        "modified_date": "2023-06-05T16:30:00"
    },
    {
        "permit_id": 77,
        "permit_reference_number": "AD02910810436-01",
        "modified_date": "2023-10-01T06:09:42"
    },
    {
        "permit_id": 78,
        "permit_reference_number": "AD02910810437-01",
        "modified_date": "2023-10-01T07:09:42"
    },
    {
        "permit_id": 84,
        "permit_reference_number": "AD02910810470-01",
        "modified_date": "2023-05-26T16:30:00"
    },
    {
        "permit_id": 85,
        "permit_reference_number": "AD02910810470_3-01",
        "modified_date": "2023-10-02T09:59:42"
    },
    {
        "permit_id": 86,
        "permit_reference_number": "AD02910810471-01",
        "modified_date": "2023-10-01T12:29:42"
    },
    {
        "permit_id": 87,
        "permit_reference_number": "AD02910810504-01",
        "modified_date": "2023-08-15T16:30:00"
    },
    {
        "permit_id": 88,
        "permit_reference_number": "AD02910810564-01",
        "modified_date": "2023-06-22T16:30:00"
    },
    {
        "permit_id": 90,
        "permit_reference_number": "AD02910810567-02",
        "modified_date": "2023-06-29T12:15:00"
    },
    {
        "permit_id": 94,
        "permit_reference_number": "AD02910810572-01",
        "modified_date": "2023-06-21T12:30:00"
    },
    {
        "permit_id": 95,
        "permit_reference_number": "AD02910810584_1-01",
        "modified_date": "2023-06-22T16:30:00"
    },
    {
        "permit_id": 97,
        "permit_reference_number": "AD02910810624-02",
        "modified_date": "2023-06-22T14:39:00"
    },
    {
        "permit_id": 100,
        "permit_reference_number": "AD02910810664-03",
        "modified_date": "2023-07-05T15:07:00"
    },
    {
        "permit_id": 101,
        "permit_reference_number": "AD02910810666-01",
        "modified_date": "2023-08-10T16:30:00"
    },
    {
        "permit_id": 102,
        "permit_reference_number": "AD02910810669_1-01",
        "modified_date": "2023-08-09T10:43:00"
    },
    {
        "permit_id": 103,
        "permit_reference_number": "AD02910810684-01",
        "modified_date": "2023-08-08T13:50:00"
    },
    {
        "permit_id": 107,
        "permit_reference_number": "AD02910810768-03",
        "modified_date": "2023-07-07T14:54:00"
    },
    {
        "permit_id": 108,
        "permit_reference_number": "AD02910811032-01",
        "modified_date": "2023-08-15T16:30:00"
    },
    {
        "permit_id": 109,
        "permit_reference_number": "AD02910811034-01",
        "modified_date": "2023-08-15T16:30:00"
    },
    {
        "permit_id": 111,
        "permit_reference_number": "AD02910811066_1-01",
        "modified_date": "2023-08-23T14:38:00"
    },
    {
        "permit_id": 114,
        "permit_reference_number": "AD0292345234-01",
        "modified_date": "2023-06-23T16:30:00"
    },
    {
        "permit_id": 116,
        "permit_reference_number": "AD02930584456_2-01",
        "modified_date": "2023-06-05T16:30:00"
    },
    {
        "permit_id": 117,
        "permit_reference_number": "AD02930584456_20-01",
        "modified_date": "2023-06-02T08:27:00"
    },
    {
        "permit_id": 118,
        "permit_reference_number": "AD02930584456_21-01",
        "modified_date": "2023-06-02T08:27:00"
    },
    {
        "permit_id": 119,
        "permit_reference_number": "AD02930584456_3-01",
        "modified_date": "2023-06-05T16:30:00"
    },
    {
        "permit_id": 122,
        "permit_reference_number": "AD02930586450-01",
        "modified_date": "2023-05-30T16:30:00"
    },
    {
        "permit_id": 124,
        "permit_reference_number": "AD02930586951_ACC-01",
        "modified_date": "2023-05-30T16:30:00"
    },
    {
        "permit_id": 125,
        "permit_reference_number": "AD02930587322_1-01",
        "modified_date": "2023-06-05T16:30:00"
    },
    {
        "permit_id": 126,
        "permit_reference_number": "AD02930587322_2-01",
        "modified_date": "2023-06-05T16:30:00"
    },
    {
        "permit_id": 127,
        "permit_reference_number": "AD02930587322_4-01",
        "modified_date": "2023-06-05T16:30:00"
    },
    {
        "permit_id": 128,
        "permit_reference_number": "AD02930587322_5-01",
        "modified_date": "2023-06-05T16:30:00"
    },
    {
        "permit_id": 129,
        "permit_reference_number": "AD02930587322_6-01",
        "modified_date": "2023-06-01T08:36:00"
    },
    {
        "permit_id": 131,
        "permit_reference_number": "AD02930590766_1-01",
        "modified_date": "2023-08-16T11:17:00"
    },
    {
        "permit_id": 132,
        "permit_reference_number": "AD02930590766_2-01",
        "modified_date": "2023-08-16T12:53:00"
    },
    {
        "permit_id": 135,
        "permit_reference_number": "AD02930590768_1-01",
        "modified_date": "2023-08-23T12:34:00"
    },
    {
        "permit_id": 136,
        "permit_reference_number": "AD02930590769-01",
        "modified_date": "2023-06-21T07:55:00"
    },
    {
        "permit_id": 138,
        "permit_reference_number": "AD02930590770-01",
        "modified_date": "2023-10-01T08:49:42"
    },
    {
        "permit_id": 139,
        "permit_reference_number": "AD02960697017-01",
        "modified_date": "2023-09-19T11:28:24"
    },
    {
        "permit_id": 140,
        "permit_reference_number": "AD02960778171_2-01",
        "modified_date": "2023-06-02T12:20:00"
    },
    {
        "permit_id": 141,
        "permit_reference_number": "AD02960778171_3-01",
        "modified_date": "2023-05-31T16:30:00"
    },
    {
        "permit_id": 142,
        "permit_reference_number": "AD02960778171_4-01",
        "modified_date": "2023-06-06T16:30:00"
    },
]



export const set3 = [
    {
        "permit_id": 58,
        "permit_reference_number": "AD022TESTING1-01",
        "modified_date": "2023-06-12T16:30:00"
    },
    {
        "permit_id": 62,
        "permit_reference_number": "AD02410810587-02",
        "modified_date": "2023-06-21T14:28:00"
    },
    {
        "permit_id": 66,
        "permit_reference_number": "AD02410810610-01",
        "modified_date": "2023-06-23T16:30:00"
    },
    {
        "permit_id": 69,
        "permit_reference_number": "AD02410810632-01",
        "modified_date": "2023-06-29T14:32:00"
    },
    {
        "permit_id": 70,
        "permit_reference_number": "AD02910663949-01",
        "modified_date": "2023-08-10T16:30:00"
    },
    {
        "permit_id": 71,
        "permit_reference_number": "AD02910680478-01",
        "modified_date": "2023-08-23T10:32:00"
    },
    {
        "permit_id": 72,
        "permit_reference_number": "AD02910810435-01",
        "modified_date": "2023-05-30T10:31:00"
    },
    {
        "permit_id": 73,
        "permit_reference_number": "AD02910810435_1-01",
        "modified_date": "2023-06-05T16:30:00"
    },
    {
        "permit_id": 74,
        "permit_reference_number": "AD02910810435_2-01",
        "modified_date": "2023-10-16T09:30:13"
    },
    {
        "permit_id": 75,
        "permit_reference_number": "AD02910810435_3-01",
        "modified_date": "2023-06-07T16:30:00"
    },
    {
        "permit_id": 76,
        "permit_reference_number": "AD02910810435_AC-01",
        "modified_date": "2023-06-05T16:30:00"
    },
    {
        "permit_id": 77,
        "permit_reference_number": "AD02910810436-01",
        "modified_date": "2023-10-01T06:09:42"
    },
    {
        "permit_id": 78,
        "permit_reference_number": "AD02910810437-01",
        "modified_date": "2023-10-01T07:09:42"
    },
    {
        "permit_id": 84,
        "permit_reference_number": "AD02910810470-01",
        "modified_date": "2023-05-26T16:30:00"
    },
    {
        "permit_id": 85,
        "permit_reference_number": "AD02910810470_3-01",
        "modified_date": "2023-10-02T09:59:42"
    },
    {
        "permit_id": 86,
        "permit_reference_number": "AD02910810471-01",
        "modified_date": "2023-10-01T12:29:42"
    },
    {
        "permit_id": 87,
        "permit_reference_number": "AD02910810504-01",
        "modified_date": "2023-08-15T16:30:00"
    },
    {
        "permit_id": 88,
        "permit_reference_number": "AD02910810564-01",
        "modified_date": "2023-06-22T16:30:00"
    },
    {
        "permit_id": 90,
        "permit_reference_number": "AD02910810567-02",
        "modified_date": "2023-06-29T12:15:00"
    },
    {
        "permit_id": 94,
        "permit_reference_number": "AD02910810572-01",
        "modified_date": "2023-06-21T12:30:00"
    },
    {
        "permit_id": 95,
        "permit_reference_number": "AD02910810584_1-01",
        "modified_date": "2023-06-22T16:30:00"
    },
    {
        "permit_id": 149,
        "permit_reference_number": "AD02964555649-01",
        "modified_date": "2023-06-23T11:47:00"
    },
    {
        "permit_id": 150,
        "permit_reference_number": "AD02964555652-01",
        "modified_date": "2023-06-27T16:30:00"
    },
    {
        "permit_id": 151,
        "permit_reference_number": "AD02964556162-01",
        "modified_date": "2023-06-20T11:35:00"
    },
    {
        "permit_id": 152,
        "permit_reference_number": "AD02964556167-01",
        "modified_date": "2023-06-27T16:30:00"
    },
    {
        "permit_id": 153,
        "permit_reference_number": "AD02964556167_1-01",
        "modified_date": "2023-06-27T16:30:00"
    },
    {
        "permit_id": 154,
        "permit_reference_number": "AD02964556167_2-01",
        "modified_date": "2023-06-27T16:30:00"
    },
    {
        "permit_id": 155,
        "permit_reference_number": "AD0296455616_2-01",
        "modified_date": "2023-06-27T16:30:00"
    },
    {
        "permit_id": 156,
        "permit_reference_number": "AD02964556181-01",
        "modified_date": "2023-06-20T11:36:00"
    },
    {
        "permit_id": 157,
        "permit_reference_number": "AD02964556192-01",
        "modified_date": "2023-06-20T11:36:00"
    },
    {
        "permit_id": 158,
        "permit_reference_number": "AD02964556568-01",
        "modified_date": "2023-06-29T16:30:00"
    },
    {
        "permit_id": 159,
        "permit_reference_number": "AD02964556619-01",
        "modified_date": "2023-06-27T16:30:00"
    },
    {
        "permit_id": 160,
        "permit_reference_number": "AD02964568704-01",
        "modified_date": "2023-08-10T16:30:00"
    },
    {
        "permit_id": 161,
        "permit_reference_number": "AD02964582170-01",
        "modified_date": "2023-08-10T16:30:00"
    },
    {
        "permit_id": 162,
        "permit_reference_number": "AD02964582204-01",
        "modified_date": "2023-08-10T16:30:00"
    },
    {
        "permit_id": 164,
        "permit_reference_number": "AD02964582204_1-02",
        "modified_date": "2023-08-21T15:32:00"
    },
    {
        "permit_id": 165,
        "permit_reference_number": "AD02964582204_2-01",
        "modified_date": "2023-08-22T09:23:00"
    },
    {
        "permit_id": 167,
        "permit_reference_number": "AD02964598110-01",
        "modified_date": "2023-08-22T15:35:00"
    },
    {
        "permit_id": 168,
        "permit_reference_number": "AD02964598110_1-01",
        "modified_date": "2023-08-22T15:34:00"
    },
    {
        "permit_id": 169,
        "permit_reference_number": "AD02964598110_2-01",
        "modified_date": "2023-08-22T15:34:00"
    },
    {
        "permit_id": 170,
        "permit_reference_number": "AD02964598111-01",
        "modified_date": "2023-08-10T16:30:00"
    },
    {
        "permit_id": 173,
        "permit_reference_number": "AD02964598132-01",
        "modified_date": "2023-08-10T16:30:00"
    },
    {
        "permit_id": 174,
        "permit_reference_number": "AD02964598135-01",
        "modified_date": "2023-08-08T13:50:00"
    },
    {
        "permit_id": 175,
        "permit_reference_number": "AD02964598383-01",
        "modified_date": "2023-08-09T08:55:00"
    },
    {
        "permit_id": 176,
        "permit_reference_number": "AD02964610332-01",
        "modified_date": "2023-08-10T16:30:00"
    },
    {
        "permit_id": 177,
        "permit_reference_number": "AD02964610339-01",
        "modified_date": "2023-08-08T13:51:00"
    },
    {
        "permit_id": 178,
        "permit_reference_number": "AD02964610344-01",
        "modified_date": "2023-08-08T13:50:00"
    },
]